## Hands on

1- Crear dominio para sagemaker.

2- Crear un user dentro del domain y crear un nuevo role de execution. Dar los permisos de cualquier bucket en s3.

3- Crear un bucket que comience por sagemaker e incluir la data que está en Dataset.

4- Abrir DataWrangler.

5- Ejecutar notebook train and deploy a model.


Si deseas hacer training jobs con instancias más grandes, debes hacer una solicitud a [AWS QUOTA](https://docs.aws.amazon.com/servicequotas/latest/userguide/request-quota-increase.html)
