Nota importante:

Usar el s3 que fue creado con el dominio en sagemaker para no tener inconvenientes.
